# Change Log

## [1.0.0] 2017-09-20
### Original Release
- Added React-Bootstrap as base framework
- Added design from Light Bootstrap Dashboard by Creative Tim
